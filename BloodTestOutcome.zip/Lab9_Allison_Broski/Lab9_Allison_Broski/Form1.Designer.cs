﻿namespace Lab9_Allison_Broski
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.medicalRecordsDataSet = new Lab9_Allison_Broski.MedicalRecordsDataSet();
            this.medicalRecordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medicalRecordsTableAdapter = new Lab9_Allison_Broski.MedicalRecordsDataSetTableAdapters.MedicalRecordsTableAdapter();
            this.tableAdapterManager = new Lab9_Allison_Broski.MedicalRecordsDataSetTableAdapters.TableAdapterManager();
            this.lstDisplay = new System.Windows.Forms.ListBox();
            this.btnAnalyze = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.medicalRecordsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalRecordsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // medicalRecordsDataSet
            // 
            this.medicalRecordsDataSet.DataSetName = "MedicalRecordsDataSet";
            this.medicalRecordsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicalRecordsBindingSource
            // 
            this.medicalRecordsBindingSource.DataMember = "MedicalRecords";
            this.medicalRecordsBindingSource.DataSource = this.medicalRecordsDataSet;
            // 
            // medicalRecordsTableAdapter
            // 
            this.medicalRecordsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.MedicalRecordsTableAdapter = this.medicalRecordsTableAdapter;
            this.tableAdapterManager.UpdateOrder = Lab9_Allison_Broski.MedicalRecordsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // lstDisplay
            // 
            this.lstDisplay.FormattingEnabled = true;
            this.lstDisplay.Location = new System.Drawing.Point(12, 77);
            this.lstDisplay.Name = "lstDisplay";
            this.lstDisplay.Size = new System.Drawing.Size(359, 186);
            this.lstDisplay.TabIndex = 0;
            // 
            // btnAnalyze
            // 
            this.btnAnalyze.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnAnalyze.Location = new System.Drawing.Point(116, 26);
            this.btnAnalyze.Name = "btnAnalyze";
            this.btnAnalyze.Size = new System.Drawing.Size(148, 45);
            this.btnAnalyze.TabIndex = 1;
            this.btnAnalyze.Text = "Analyze";
            this.btnAnalyze.UseVisualStyleBackColor = false;
            this.btnAnalyze.Click += new System.EventHandler(this.btnAnalyze_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 278);
            this.Controls.Add(this.btnAnalyze);
            this.Controls.Add(this.lstDisplay);
            this.Name = "frmMain";
            this.Text = "Who\'s Gonna Die?";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.medicalRecordsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalRecordsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MedicalRecordsDataSet medicalRecordsDataSet;
        private System.Windows.Forms.BindingSource medicalRecordsBindingSource;
        private MedicalRecordsDataSetTableAdapters.MedicalRecordsTableAdapter medicalRecordsTableAdapter;
        private MedicalRecordsDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ListBox lstDisplay;
        private System.Windows.Forms.Button btnAnalyze;
    }
}

