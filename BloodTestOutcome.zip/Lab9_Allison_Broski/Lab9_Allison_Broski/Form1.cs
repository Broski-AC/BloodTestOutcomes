﻿/*LAB #9
'Fall 2017
‘Allison Broski
‘I fully understand the following statement. ‘OU PLAGIARISM POLICY
‘All members of the academic community at Oakland are expected to practice and 
uphold ‘standards of academic integrity and honesty. An instructor is expected to 
inform and instruct ‘students about the procedures and standards of research and 
documentation required of students ‘in fulfilling course work.A student is expected 
to follow such instructions and be sure the rules ‘and procedures are understood in 
order to avoid inadvertent misrepresentation of her/his work. ‘Students must assume 
that individual (unaided) work on exams and lab reports and documentation ‘of sources 
is expected unless the instructor specifically says that is not necessary.
‘The following definitions are some examples of academic dishonesty:
 ‘Plagiarizing from work of others.Plagiarism is using someone else's work or ideas 
without ‘giving the other person credit; by doing this, a student is, in effect, 
claiming credit for ‘someone else's thinking.Whether the student has read or heard the 
information he/she uses, ‘the student must document the source of information.
When dealing with written sources,
‘a clear distinction would be made between quotations (which reproduce information 
from ‘the source word-for-word within quotation marks) and paraphrases(which digest 
the ‘source information and produce it in the student's own words). Both direct quotations 
and ‘paraphrases must be documented. Just because a student rephrases, condenses or selects
‘from another person's work, the ideas are still the other person's, and failure to give
‘credit constitutes misrepresentation of the student's actual work and plagiarism of
‘another's ideas. Naturally, buying a paper and handing it in as one's own work is ‘plagiarism.
 ‘Cheating on lab reports falsifying data or submitting data not based on student's own work.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;


namespace Lab9_Allison_Broski
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void medicalRecordsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.medicalRecordsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.medicalRecordsDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medicalRecordsDataSet.MedicalRecords' table. You can move, or remove it, as needed.
            this.medicalRecordsTableAdapter.Fill(this.medicalRecordsDataSet.MedicalRecords);

        }

        XElement Blood = XElement.Load(@"BloodTests.xml"); //Loading in the XML file

        //Creating a structure to hold values in for calculations
        struct BloodTest
        {
            public int PatientID;
            public double Bilirubin;
            public double SGot;
            public double Albumin;
            public double AlkPhosphate;
        }


        private void btnAnalyze_Click(object sender, EventArgs e) //This is the event from which everything is run
        {
            Bilirubin(); //Runs the Bilirubin method
            SGOT(); //Runs the SGOT method
            Albumin(); //Runs the Albumin method
            AlkPhosphate(); //Runs the AlkPhosphate method

        }



        public void Bilirubin()
        {
            //Working just with Bilirubin
            var BilliRubin = from blood in Blood.Descendants("BloodTests")
                             let PatientID = (int)blood.Element("PatientID")
                             let Bilirubin = (double)blood.Element("Bilirubin")
                             select new { PatientID, Bilirubin };

            BloodTest[] BloodTests = new BloodTest[BilliRubin.Count()]; //New strucuted array with a size of Billirubin
                                                                        //Within each slot of the BloodTests array, there exists the structure BloodTest

            int u = 0;
            foreach (var blood in BilliRubin)
            {
                BloodTests[u].PatientID = blood.PatientID;
                BloodTests[u].Bilirubin = blood.Bilirubin;
                u++;
            }
            // for every decentant of BloodTests selected from the LINQ BilliRubin
            //Assign the decendant Patient ID to the spot in the array BloodTests labeled PatientID
            //Similar procedure for Bilirubin

            int i = 0;
            double DeadSum = 0;
            double DeadSquare = 0;
            double DeadCount = 0;
            double GoodJobSum = 0;
            double GoodJobSquare = 0;
            double GoodJobCathy = 0;
            int p = 0;

            foreach (var Bilirubin in BloodTests)
            {
                if (BloodTests[i].Bilirubin != -99)
                {
                    var PatientData = from identity in medicalRecordsDataSet.MedicalRecords //Going through the medical records
                                      let ID = (int)identity.PatientID //Identifying ID as the column Patient ID in the datasource
                                      where ID == BloodTests[i].PatientID //Making sure the IDs match between the datasource and structured array
                                      let status = (int)identity.Alive //Identifying status as the column Alive within the datasource
                                      select new { identity.Alive }; //Selecting the column

                    int[] Status = new int[PatientData.Count()];//Creating an array equal to the size of the above LINQ query to hold the identity.Alive values

                    int o = 0;
                    foreach (var identity in PatientData) //Taking each PatientID that matches the ID and putting it into the array. This technically only gets one value each time
                    {
                        Status[o] = identity.Alive;
                        o++;
                    }

                    if (Status[p] == 1) //Saying if the patient is dead. The counters will be used for calculations later
                    {
                        DeadSum += BloodTests[i].Bilirubin;
                        DeadSquare += Math.Pow(BloodTests[i].Bilirubin, 2);
                        DeadCount += 1;
                    }
                    else //implies that they are alive
                    {
                        GoodJobSum += BloodTests[i].Bilirubin;
                        GoodJobSquare += Math.Pow(BloodTests[i].Bilirubin, 2);
                        GoodJobCathy += 1;
                    }
                    i++; //Increment and run the code again
                }
                else
                {
                    i++; //Increment and run the code again
                }

            }

            double AverageDeadBili = 0;
            double DeadStandDev = 0;
            double AverageGoodJobBili = 0;
            double AliveStandDev = 0;

            AverageDeadBili = DeadSum / DeadCount; //Calculates the average of the dead people
            AverageGoodJobBili = GoodJobSum / GoodJobCathy; //Calculates the average of the alive people
            DeadStandDev = Math.Sqrt((DeadSquare / DeadCount) - Math.Pow(AverageDeadBili, 2)); //Calculates the StD of the dead people
            AliveStandDev = Math.Sqrt((GoodJobSquare / GoodJobCathy) - Math.Pow(AverageGoodJobBili, 2)); //Calculates the StD of the alive people

            //Puts everything in the list box
            lstDisplay.Items.Add("Average Bilirubin (Dead):" + AverageDeadBili.ToString("##0.##"));
            lstDisplay.Items.Add("Average Bilirubin (Alive):" + AverageGoodJobBili.ToString("##0.##"));
            lstDisplay.Items.Add("Std. Dev Bilirubin (Dead):" + DeadStandDev.ToString("##0.##"));
            lstDisplay.Items.Add("Std. Dev Bilirubin (Alive):" + AliveStandDev.ToString("##0.##"));
        }
        public void SGOT() //Working with SGot
        {
            var SGOT = from blood in Blood.Descendants("BloodTests")
                       let PatientID = (int)blood.Element("PatientID")
                       let sgot = (double)blood.Element("SGot")
                       select new { PatientID, sgot };

            BloodTest[] BloodTests = new BloodTest[SGOT.Count()]; //New strucuted array with a size of SGOT
                                                                  //Within each slot of the BloodTests array, there exists the structure BloodTest

            int u = 0;
            foreach (var blood in SGOT)
            {
                BloodTests[u].PatientID = blood.PatientID;
                BloodTests[u].SGot = blood.sgot;
                u++;
            }

            int i = 0;
            double DeadSum = 0;
            double DeadSquare = 0;
            double DeadCount = 0;
            double GoodJobSum = 0;
            double GoodJobSquare = 0;
            double GoodJobNate = 0;
            int p = 0;

            foreach (var SGot in BloodTests)
            {
                if (BloodTests[i].SGot != -99)
                {
                    var PatientData = from identity in medicalRecordsDataSet.MedicalRecords //Going through the medical records
                                      let ID = (int)identity.PatientID //Identifying ID as the column Patient ID in the datasource
                                      where ID == BloodTests[i].PatientID //Making sure the IDs match between the datasource and structured array
                                      let status = (int)identity.Alive //Identifying status as the column Alive within the datasource
                                      select new { identity.Alive }; //Selecting the column

                    int[] Status = new int[PatientData.Count()];//Creating an array equal to the size of the above LINQ query to hold the identity.Alive values

                    int o = 0;
                    foreach (var identity in PatientData) //Taking each PatientID that matches the ID and putting it into the array
                    {
                        Status[o] = identity.Alive;
                        o++;
                    }

                    if (Status[p] == 1) //Saying if the patient is dead
                    {
                        DeadSum += BloodTests[i].SGot;
                        DeadSquare += Math.Pow(BloodTests[i].SGot, 2);
                        DeadCount += 1;
                    }
                    else //implies that they are alive
                    {
                        GoodJobSum += BloodTests[i].SGot;
                        GoodJobSquare += Math.Pow(BloodTests[i].SGot, 2);
                        GoodJobNate += 1;
                    }
                    i++; //Could be stuck into above if/else
                }
                else
                {
                    i++;
                }
            }

            double AverageDeadSGot = 0;
            double DeadStandDev = 0;
            double AverageGoodJobSGot = 0;
            double AliveStandDev = 0;

            //All the calculations
            AverageDeadSGot = DeadSum / DeadCount;
            AverageGoodJobSGot = GoodJobSum / GoodJobNate;
            DeadStandDev = Math.Sqrt((DeadSquare / DeadCount) - (Math.Pow(AverageDeadSGot, 2)));
            AliveStandDev = Math.Sqrt((GoodJobSquare / GoodJobNate) - (Math.Pow(AverageGoodJobSGot, 2)));

            lstDisplay.Items.Add("");
            lstDisplay.Items.Add("Average SGot (Dead):" + AverageDeadSGot.ToString("##0.##"));
            lstDisplay.Items.Add("Average SGot (Alive):" + AverageGoodJobSGot.ToString("##0.##"));
            lstDisplay.Items.Add("Std. Dev SGot (Dead):" + DeadStandDev.ToString("##0.##"));
            lstDisplay.Items.Add("Std. Dev SGot (Alive):" + AliveStandDev.ToString("##0.##"));
        }

        public void Albumin()
        {
            var Allbumin = from blood in Blood.Descendants("BloodTests")
                             let PatientID = (int)blood.Element("PatientID")
                             let Albumin = (double)blood.Element("Albumin")
                             select new { PatientID, Albumin };

            BloodTest[] BloodTests = new BloodTest[Allbumin.Count()]; //New strucuted array with a size of Allbumin (because that's a thing)
                                                                        //Within each slot of the BloodTests array, there exists the structure BloodTest

            int u = 0;
            foreach (var blood in Allbumin)
            {
                BloodTests[u].PatientID = blood.PatientID;
                BloodTests[u].Albumin = blood.Albumin;
                u++;
            }
            // for every decentant of BloodTests selected from the LINQ Allbumin
            //Assign the decendant Patient ID to the spot in the array BloodTests labeled PatientID
            //Similar procedure for Albumin

            int i = 0;
            double DeadSum = 0;
            double DeadSquare = 0;
            double DeadCount = 0;
            double GoodJobSum = 0;
            double GoodJobSquare = 0;
            double GoodJobReygan = 0;
            int p = 0;

            foreach (var Albumin in BloodTests)
            {
                if (BloodTests[i].Albumin != -99)
                {
                    var PatientData = from identity in medicalRecordsDataSet.MedicalRecords //Going through the medical records
                                      let ID = (int)identity.PatientID //Identifying ID as the column Patient ID in the datasource
                                      where ID == BloodTests[i].PatientID //Making sure the IDs match between the datasource and structured array
                                      let status = (int)identity.Alive //Identifying status as the column Alive within the datasource
                                      select new { identity.Alive }; //Selecting the column

                    int[] Status = new int[PatientData.Count()];//Creating an array equal to the size of the above LINQ query to hold the identity.Alive values

                    int o = 0;
                    foreach (var identity in PatientData) //Taking each PatientID that matches the ID and putting it into the array
                    {
                        Status[o] = identity.Alive;
                        o++;
                    }
  
                    if (Status[p] == 1) //Saying if the patient is dead
                    {
                        DeadSum += BloodTests[i].Albumin;
                        DeadSquare += Math.Pow(BloodTests[i].Albumin, 2);
                        DeadCount += 1;
                    }
                    else //implies that they are alive
                    {
                        GoodJobSum += BloodTests[i].Albumin;
                        GoodJobSquare += Math.Pow(BloodTests[i].Albumin, 2);
                        GoodJobReygan += 1;
                    }
                    i++; //Could be stuck into above if/else
                }
                else
                {
                    i++;
                }

            }

            double AverageDeadAlbu = 0;
            double DeadStandDev = 0;
            double AverageGoodJobAlbu = 0;
            double AliveStandDev = 0;

            //All the calculations
            AverageDeadAlbu = DeadSum / DeadCount;
            AverageGoodJobAlbu = GoodJobSum / GoodJobReygan;
            DeadStandDev = Math.Sqrt((DeadSquare / DeadCount) - Math.Pow(AverageDeadAlbu, 2));
            AliveStandDev = Math.Sqrt((GoodJobSquare / GoodJobReygan) - Math.Pow(AverageGoodJobAlbu, 2));

            lstDisplay.Items.Add("");
            lstDisplay.Items.Add("Average Albumin (Dead):" + AverageDeadAlbu.ToString("##0.##"));
            lstDisplay.Items.Add("Average Albumin (Alive):" + AverageGoodJobAlbu.ToString("##0.##"));
            lstDisplay.Items.Add("Std. Dev Albumin (Dead):" + DeadStandDev.ToString("##0.##"));
            lstDisplay.Items.Add("Std. Dev Albumin (Alive):" + AliveStandDev.ToString("##0.##"));
        }

        public void AlkPhosphate()
        {
            var AllkP = from blood in Blood.Descendants("BloodTests")
                           let PatientID = (int)blood.Element("PatientID")
                           let AlkP = (double)blood.Element("AlkPhosphate")
                           select new { PatientID, AlkP };

            BloodTest[] BloodTests = new BloodTest[AllkP.Count()]; //New strucuted array with a size of AllkP
                                                                      //Within each slot of the BloodTests array, there exists the structure BloodTest

            int u = 0;
            foreach (var blood in AllkP)
            {
                BloodTests[u].PatientID = blood.PatientID;
                BloodTests[u].AlkPhosphate = blood.AlkP;
                u++;
            }
            // for every decentant of BloodTests selected from the LINQ AllkP
            //Assign the decendant Patient ID to the spot in the array BloodTests labeled PatientID
            //Similar procedure for AlkP

            int i = 0;
            double DeadSum = 0;
            double DeadSquare = 0;
            double DeadCount = 0;
            double GoodJobSum = 0;
            double GoodJobSquare = 0;
            double GoodJobJames = 0;
            int p = 0;

            foreach (var AlkP in BloodTests)
            {
                if (BloodTests[i].AlkPhosphate != -99)
                {
                    var PatientData = from identity in medicalRecordsDataSet.MedicalRecords //Going through the medical records
                                      let ID = (int)identity.PatientID //Identifying ID as the column Patient ID in the datasource
                                      where ID == BloodTests[i].PatientID //Making sure the IDs match between the datasource and structured array
                                      let status = (int)identity.Alive //Identifying status as the column Alive within the datasource
                                      select new { identity.Alive }; //Selecting the column

                    int[] Status = new int[PatientData.Count()];//Creating an array equal to the size of the above LINQ query to hold the identity.Alive values

                    int o = 0;
                    foreach (var identity in PatientData) //Taking each PatientID that matches the ID and putting it into the array
                    {
                        Status[o] = identity.Alive;
                        o++;
                    }

                    if (Status[p] == 1) //Saying if the patient is dead
                    {
                        DeadSum += BloodTests[i].AlkPhosphate;
                        DeadSquare += Math.Pow(BloodTests[i].AlkPhosphate, 2);
                        DeadCount += 1;
                    }
                    else //implies that they are alive
                    {
                        GoodJobSum += BloodTests[i].AlkPhosphate;
                        GoodJobSquare += Math.Pow(BloodTests[i].AlkPhosphate, 2);
                        GoodJobJames += 1;
                    }
                    i++; //Could be stuck into above if/else
                }
                else
                {
                    i++;
                }

            }

            double AverageDeadAlkP = 0;
            double DeadStandDev = 0;
            double AverageGoodJobAlkP = 0;
            double AliveStandDev = 0;

            //All the calculations
            AverageDeadAlkP = DeadSum / DeadCount;
            AverageGoodJobAlkP = GoodJobSum / GoodJobJames;
            DeadStandDev = Math.Sqrt((DeadSquare / DeadCount) - Math.Pow(AverageDeadAlkP, 2));
            AliveStandDev = Math.Sqrt((GoodJobSquare / GoodJobJames) - Math.Pow(AverageGoodJobAlkP, 2));

            lstDisplay.Items.Add("");
            lstDisplay.Items.Add("Average AlkPhosphate (Dead):" + AverageDeadAlkP.ToString("##0.##"));
            lstDisplay.Items.Add("Average AlkPhosphate (Alive):" + AverageGoodJobAlkP.ToString("##0.##"));
            lstDisplay.Items.Add("Std. Dev AlkPhosphate (Dead):" + DeadStandDev.ToString("##0.##"));
            lstDisplay.Items.Add("Std. Dev AlkPhosphate (Alive):" + AliveStandDev.ToString("##0.##"));
        }


    }
}
